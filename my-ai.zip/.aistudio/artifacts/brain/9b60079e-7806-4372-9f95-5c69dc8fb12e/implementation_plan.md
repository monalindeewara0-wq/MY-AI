# MY AI — Premium Android AI Assistant

A native Android AI assistant inspired by the clean, modern aesthetic of Meta AI, created by Monal from Sri Lanka. MY AI features multi-turn conversational streaming, multimodal image analysis via Android Photo Picker, advanced Sinhala, English, and Singlish comprehension, and persistent local chat history using Room.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions have been adopted to guarantee a reliable, production-grade native experience:
> - **AI Engine**: Powered by **Firebase AI Logic** (`Firebase.ai.generativeModel("gemini-3.8-flash")`) with streaming responses and App Check attestation, strictly adhering to zero-trust security without exposing private API keys in the APK.
> - **Language Intelligence**: Automatic detection and native responses in **Sinhala**, **English**, **Singlish** (Sinhala written in Latin phonetics, e.g., *"Mata GTA game ekak kiyanna"*), and mixed bilingual queries.
> - **Local Chat Persistence**: Stored on-device with **Room Database** (Flow-driven reactive queries), enabling offline history browsing, conversation renaming, message deletion, and zero data loss between app launches.
> - **Creator Identity**: Strict system instructions identifying MY AI as created by Monal from Sri Lanka, with dedicated About and Settings pages.

---

### 1. Overview & Core Concept

- **What It Does**: MY AI is a personal conversational AI assistant for Android with broad subject expertise (WWE, sports, cricket, video games, PC hardware, mobile phones, programming, food, science, and everyday questions). Users can chat seamlessly in Sinhala or English and attach photos from their device using the zero-permission Android Photo Picker for instant visual reasoning.
- **Target Audience / Persona**: Sri Lankan and global Android users seeking a modern, fast, bilingual companion that understands local dialect nuances (Singlish/Sinhala) alongside global tech and entertainment topics.
- **Key Value**: Real cloud-powered Gemini intelligence, streaming Time-to-First-Token in under two seconds, local chat memory that survives restarts, and a Meta AI-inspired aesthetic.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **First Launch & Hero Welcome**:
   - Animated splash and transition to the chat canvas.
   - Header with MY AI glowing badge, "New Chat" quick action, and conversation history drawer toggle.
   - Welcome hero greeting: *"Hey! I'm MY AI."* accompanied by the Sinhala greeting: *"ආයුබෝවන්! මම MY AI. ඔයාට අද මගෙන් මොනවද දැනගන්න ඕනේ?"*
   - Interactive prompt starter pills across categories (e.g., *WWE & Wrestling*, *GTA & Gaming*, *Tech & Phones*, *Sinhala Knowledge*).
2. **Chat & Streaming Dialogue**:
   - Floating rounded message input with an Image Attachment button, Send button, and expandable multi-line text field.
   - User message bubble (accent blue gradient, right-aligned) and MY AI message bubble (dark slate surface with subtle cyan border, left-aligned).
   - Real-time token streaming with smooth auto-scroll to bottom.
   - Message actions: 1-tap Copy, Regenerate, and Timestamp indicators.
3. **Multimodal Image Understanding**:
   - Tap photo icon to trigger the Android Photo Picker (`PickVisualMedia`).
   - Image thumbnail preview with a quick "Remove" badge directly above the input box before sending.
   - Gemini multimodal analysis delivering detailed object identification, OCR text transcription, scene descriptions, and answering specific questions about the image.
4. **Conversation Management**:
   - Modal drawer / history panel listing all previous chats sorted by date.
   - Actions to switch active chat, rename conversations, delete individual chats, or clear entire history.
5. **Settings & Creator Tribute**:
   - Theme toggle (Dark / Light / System default).
   - "About MY AI" screen detailing Creator Monal, Country of Origin (Sri Lanka), and AI engine version.
   - Firebase status diagnostics with explicit instructions if backend attestation is pending.

#### Visual Identity & Theme
- **Theme**: Luxury Obsidian & Electric Blue (Meta AI inspired).
- **Dark Palette**: Deep Obsidian background (`#0B0F19`), Card/Bubble surface (`#161E2E`), Electric Blue accent (`#2563EB` / `#3B82F6`), Neon Cyan glow (`#06B6D4`), crisp white typography (`#F8FAFC`), muted slate secondary text (`#94A3B8`).
- **Light Palette**: Crisp Ice White (`#F8FAFC`), Elevated Card surface (`#FFFFFF`), Vibrant Royal Blue (`#1D4ED8`), Charcoal text (`#0F172A`).
- **Shapes & Typography**: Continuous 24dp pill curves for bubbles, floating pill input field, crisp sans-serif typography with generous line-height for both Sinhala Unicode script and Latin text.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Firebase AI Logic (`gemini-3.8-flash`) vs Legacy Direct API**:
  - *Chosen Approach*: Use `Firebase.ai.generativeModel("gemini-3.8-flash")` with App Check and coroutine timeout guards (60s).
  - *Why*: Eliminates client-side API key leakage, meets enterprise zero-trust standards, and provides Gemini 3-generation speed for multimodal streaming.
- **Decision 2: Room SQLite Database vs In-Memory State**:
  - *Chosen Approach*: Full Room implementation with `ConversationEntity` and `MessageEntity`.
  - *Why*: Chats and attached photo thumbnail URIs remain preserved across process deaths and device restarts.
- **Decision 3: Android Photo Picker vs Camera Permission**:
  - *Chosen Approach*: `ActivityResultContracts.PickVisualMedia`.
  - *Why*: Conforms to Google Play zero-storage-permission standards while providing a native photo selection sheet.
- **Decision 4: Multi-turn History Assembly**:
  - *Chosen Approach*: Send active conversation history to Gemini during generation so follow-up questions understand conversational context seamlessly.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI                       │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │   Top AppBar    │  │  Message List   │  │   Input Dock    │  │
│  │ (New Chat/Nav)  │  │(Streaming/Bubbl)│  │ (Picker/Send)   │  │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘  │
│           │                    │                    │           │
└───────────┼────────────────────┼────────────────────┼───────────┘
            ▼                    ▼                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                          ChatViewModel                          │
│  • uiState: StateFlow<ChatUiState>                              │
│  • conversations: StateFlow<List<Conversation>>                 │
│  • sendMessage() / streamAnswer() / retry() / pickImage()       │
└──────────────┬──────────────────────────────────┬───────────────┘
               │                                  │
               ▼                                  ▼
┌──────────────────────────────┐  ┌───────────────────────────────┐
│     FirebaseAiRepository     │  │       ChatRoomRepository      │
│  • Firebase.ai               │  │  • AppDatabase (Room)         │
│  • gemini-3.8-flash          │  │  • ConversationDao            │
│  • Multimodal Content builder│  │  • MessageDao                 │
│  • App Check Attestation     │  │  • Reactive Flow Queries      │
└──────────────────────────────┘  └───────────────────────────────┘
```

#### Room Entities & Schema
- `conversations`: `id` (PK, Long), `title` (String), `createdAt` (Long), `updatedAt` (Long)
- `messages`: `id` (PK, Long), `conversationId` (FK, Long), `role` (user / model / error), `content` (String), `imageUri` (String?), `timestamp` (Long)

#### Interactive Component & State Mapping
- `MainActivity.onCreate()`: Runs `configureAppCheck(this, intent)` synchronously before UI setup.
- `ChatScreen`: Observes `ChatViewModel.uiState`. When user sends a prompt, creates a message in Room, triggers `generateContentStream()`, updates the UI token-by-token, and commits final response to Room.
- `DrawerNavigation`: Allows switching conversation IDs, initiating a clean "New Chat", renaming via dialog, or deleting conversations with animated swipe-to-dismiss or context menus.
- `About & Settings Screen`: Displays Monal's creator info, country of origin (Sri Lanka), theme switchers, and database clearing tools.
